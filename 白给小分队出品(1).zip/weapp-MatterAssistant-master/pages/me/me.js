const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    password: "",
    password_check: "",
    schoolid: 0,
    schoolInfo: [],
    count:100,
    count1:0,
    count2:0,
    value1:'',
    value2:'',
    firstTime:'0',
    inmoney: 100,
    cost: 100,
    little: 100,
    row1: "",
    row2: "",
    row3: "", 
    flag:true,
    password_show: false
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  addUser: function(){
    var that = this;
    var password = that.data.password;
    var password_check = that.data.password_check;
    if(password == password_check){
      
    }else{
      wx.showModal({
        title: '提示',
        content: '对不起！您输入的两次密码不同！',
        success(res) {
          if (res.confirm) {
            that.setData({
              password_show: true
            });
          } else if (res.cancel) {
            that.setData({
              password_show: false
            });
          }
        }
      })
    }
  },
  onBindTap:function(){
    var D=(new Date()).getDate().toString();
    if(D != wx.getStorageSync('D')){
      wx.setStorageSync('D', D);
      wx.setStorage({
        key: 'FirstTime',
        data: (parseInt(this.data.firstTime) + 1).toString(),
      })
      var that = this;
      var firstTime = wx.getStorage({
        key: 'FirstTime',
        success: function (res) {
          that.setData({
            firstTime: res.data,
            flag:false
          })
          wx.showToast({
            title: '签到成功！',
            icon: 'success',
            duration: 1200,
            mask: true,
            count1: count1+1,
            count2: count2+1
          })
          console.log(count1,count2)
        },
      })
      console.log(520)
    }
    else{
      wx.showToast({
        title: '今日打卡已完成！',
        icon:'loading',
        duration:1200,
        mask:true
      })
    }
  },
  onShow:function(options){
    var that = this;
    var firstTime = wx.getStorage({
      key: 'FirstTime',
      success: function (res) {
        that.setData({
          firstTime: res.data
        })
      },
    })
    var D = (new Date()).getDate().toString();
    if (D != wx.getStorageSync('D')){
      this.setData({
        flag:true
      })
    }else{
      this.setData({
        flag:false
      })
    }
  },
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    });
  },
  passwordCheckInput: function (e) {
    this.setData({
      password_check: e.detail.value
    });
  } 
})