// pages/pet/pet.js
Page({
  chooseOne:function(){
    wx.navigateTo({
      url: '/pages/pet2/pet2',
    })
  },
  
})