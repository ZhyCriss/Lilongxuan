// pages/pet3/pet3.js
Page({
  data: {
    schoolid: 0,
    schoolInfo: [],
    count:100,
    count1:0,
    count2:0,
    value1:'',
    value2:'',
    firstTime:'0',
    inmoney: 100,
    cost: 100,
    little: 100,
    row1: "",
    row2: "",
    row3: "", 
    flag:true,
    schoolInfo1: [
        {
          "myPet":"我的宠物",
          "pet_name": "龟龟",
        },
        {
          "pet_name": "史莱姆",
        },
        {
          "pet_name": "猫猫",
        },
        {
          "pet_name": "狗狗",
        }

  ],
  },
  onLoad: function (options) {
    var that = this;
    this.setData({
      schoolid: options.schoolid
    })
    var list5 = [this.data.inmoney, this.data.cost, this.data.little];
    duration: 3000,
    list5[0]= this.data.inmoney-10;
    list5[1]= this.data.cost-10;
    list5[2]= this.data.little-10;
    var max = Math.max.apply(null, list5 ); 
    console.log(max)
    var unit = 380/max;
    console.log(unit)
  
    this.setData({
      row1: list5[0]* unit,
      row2: list5[1] * unit,
      row3: list5[2] * unit,
    })
  },
  
  onReady: function () {
    var that = this;
    let sid = this.data.schoolid;
    let sinfo;
    console.log("宠物id:" + sid);
    //这里根据id的不同，去绑定不同的数据到页面
    if (sid == 1) {
      sinfo = this.data.schoolInfo1[0];
    }
    if (sid == 2) {
      sinfo = this.data.schoolInfo1[1];

    }
    if (sid == 3) {
      sinfo = this.data.schoolInfo1[2];

    }
    if (sid == 4) {
      sinfo = this.data.schoolInfo1[3];

    }
    console.log(sinfo);
    this.setData({
      schoolInfo: sinfo
    })
  },
  use1(){
    if (this.data.count1 <= 0) {
      wx.showToast({
        title: '您的口粮不足！',
        duration: 300,
      })
    }
    else{
        if(this.data.inmoney>=100){
          wx.showToast({
            title: '健康值已满',
            duration:300,
          })
        }
        else{this.setData({
          inmoney:this.data.inmoney+5,
          count1:this.data.count1-1,
        })}
        if(this.data.cost>=100){
          wx.showToast({
            title: '饥饿值已满',
            duration:300,
          })
        }else{
          this.setData({
            cost:this.data.cost+10,
          })
        }
    }
  },
  use2(){
    if (this.data.count2 <= 0) {
      wx.showToast({
        title: '您的玩具不足！',
        duration: 300,
      })
    }
    else{
     if(this.data.little>=100){
       wx.showToast({
         title: '活跃值已满',
         duration:300,
       })
     }
     else{this.setData({
      count2: this.data.count2-1,
      little:this.data.little+10,
      });}
    }
  },
  onBindTap:function(){
    var D=(new Date()).getDate().toString();
    if(D != wx.getStorageSync('D')){
      wx.setStorageSync('D', D);
      wx.setStorage({
        key: 'FirstTime',
        data: (parseInt(this.data.firstTime) + 1).toString(),
      })
      var that = this;
      var firstTime = wx.getStorage({
        key: 'FirstTime',
        success: function (res) {
          that.setData({
            firstTime: res.data,
            flag:false
          })
          wx.showToast({
            title: '签到成功！',
            icon: 'success',
            duration: 1200,
            mask: true,
            count1: count1++,
            count2: count2++
          })
          console.log(count1,count2)
        },
      })
      console.log(520)
    }
    else{
      wx.showToast({
        title: '获得口粮、玩具*1！',
        icon:'loading',
        duration:500,
        mask:true
      })
      this.setData({
        count1: this.data.count1+1,
        count2: this.data.count2+1,
        });
    }
  },
  onShow:function(options){
    var that = this;
    var firstTime = wx.getStorage({
      key: 'FirstTime',
      success: function (res) {
        that.setData({
          firstTime: res.data
        })
      },
    })
    var D = (new Date()).getDate().toString();
    if (D != wx.getStorageSync('D')){
      this.setData({
        flag:true
      })
    }else{
      this.setData({
        flag:false
      })
    }
    this.countDown1();
    this.countDown2();
    this.countDown3();
  },
  countDown1: function () {
    let that = this;
    let inmoney = that.data.inmoney;//获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
      that.data.timer = setInterval(function () {//这里把setInterval赋值给变量名为timer的变量
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (inmoney == 0) {
          wx.showToast({
            title: 'aaa',
          })
          clearInterval(that.data.timer);
          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          // clearInterval(that.data.timer);
          //关闭定时器之后，可作其他处理codes go here
        }else{
        //每隔一秒countDownNum就减一，实现同步
        inmoney--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        that.setData({
          inmoney: inmoney
        })}
      }, 1000)
  },
  countDown2: function () {
    let that = this;
    let cost = that.data.cost;//获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
      that.data.timer = setInterval(function () {//这里把setInterval赋值给变量名为timer的变量
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (cost == 0) {
          wx.showToast({
            title: 'aaa',
          })
          clearInterval(that.data.timer);
          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          // clearInterval(that.data.timer);
          //关闭定时器之后，可作其他处理codes go here
        }else{
        //每隔一秒countDownNum就减一，实现同步
        cost--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        that.setData({
          cost: cost
        })}
      }, 2000)
  },
  countDown3: function () {
    let that = this;
    let little = that.data.little;//获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
      that.data.timer = setInterval(function () {//这里把setInterval赋值给变量名为timer的变量
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (little == 0) {
          wx.showToast({
            title: 'aaa',
          })
          clearInterval(that.data.timer);
          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          // clearInterval(that.data.timer);
          //关闭定时器之后，可作其他处理codes go here
        }else{
        //每隔一秒countDownNum就减一，实现同步
        little--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        that.setData({
          little: little
        })}
      }, 2000)
  },

  


  startSetInter: function(){
    var that = this;
    that.data.setInter = setInterval(
        function () {
          inmoney= that.data.inmoney-10;
          cost= that.data.cost-10;
          little= that.data.little-10;
          console.log(22333)
        }
  , 2000)
},
})
