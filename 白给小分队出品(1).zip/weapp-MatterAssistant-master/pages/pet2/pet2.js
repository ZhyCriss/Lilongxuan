// pages/pet2/pet2.js

const app = getApp();
var page = 1;
Page({
  data: {
    bannerUrls: [ //轮播图的图片
      {
        url: '/images/bear.png',
        linkUrl: ''
      },
      {
        url: '/images/猫.jpg',
        linkUrl: ''
      },
      {
        url: '/images/二哈.jpg',
        linkUrl: ''
      }
    ],
 	imgheights:'',
    pets: [{
        "id": 1,
        "pic": "../../images/宠物龟.png",
      },
      {
        "id": 2,
        "pic": "../../images/史莱姆.png",
      },
      {
        "id": 3,
        "pic": "../../images/cat.png",
      },
      {
        "id": 4,
        "pic": "../../images/dog.png",
      }
    ],
  },
  onLoad:function(){
    var that = this;
     that.imageLoad();
  },
   imageLoad: function () {
     var that = this;
     wx.getSystemInfo({
       success: function (res) {
       //我们设计图片的尺寸是750*388
         var width = res.windowWidth;//获取当前屏幕的宽度
         var rao = 750/width; //图片宽度／屏幕的宽度
         var height = 500/rao; //图片高度／比例
         that.setData({
           'imgheights':height //设置等比缩放的宽度
         })
       },
     })
   },
  /**
   * 打开详情页面
   */
  gotoschooldetail: function(e) {
    var that = this;
    let schoolid = e.currentTarget.dataset.id; //获取index值
    console.log(schoolid);
    wx.navigateTo({
      url: '../pet3/pet3?schoolid=' + schoolid
    });
  },
})